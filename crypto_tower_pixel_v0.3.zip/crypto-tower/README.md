# Crypto Tower — Pixel City v0.3
Free modular HTML5 Telegram Mini App prototype. No crypto payments.

## Run
Serve this directory over HTTP(S), e.g. `python3 -m http.server 8000`, then open http://localhost:8000. ES modules will not reliably run from file:// or a ChatGPT file preview.

## Publish
Upload the contents of this folder to a new GitHub repository and enable GitHub Pages (Settings → Pages → Deploy from branch). Open the HTTPS URL on iPhone/Safari. In Telegram, create a bot with @BotFather, configure its menu button / Mini App URL to the HTTPS URL. Do not paste your bot token into client code.

## Structure
- src/game/engine.js — physics, procedural platforms, drawing
- src/ui/ — reserved for menus and skins
- src/telegram/bridge.js — Telegram WebApp integration
- src/services/records.js — local record storage, replaceable by authenticated backend
- assets/ — future sprites/audio

## Notes
Best score is local to the device, not a global Telegram leaderboard. Before enabling public rewards, implement server-side score verification, authentication and anti-cheat.
